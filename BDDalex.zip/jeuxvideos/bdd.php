<?php
    $nom = $_GET["user_nom"];
    $motdepasse = $_GET["user_motdepasse"];

      function checkConnexion($user,$password){
        try {
            $base = new PDO('mysql:host=localhost; dbname=videogames', 'root', '');
          }
          catch(exception $e) {
            die('Erreur '.$e->getMessage());
          }
        $sql =  'SELECT * FROM `login` WHERE `nomdecompte`="'.$user.'" AND `motdepasse`="'.$password.'"';
        $resultat = $base->query($sql)->rowCount();
        echo $resultat;
        return $resultat;
      }

if(checkConnexion($nom,$motdepasse) == 0){
    header("Location: index.php?error=true");
} else {
    header("Location: oui.php");
}

?>