<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
	<title>Bienvenue</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<body>
	<div style="color: blue">
	Bienvenue
	</div>

	<section class="container">
	<?php 
	$bdd = new PDO('mysql:host=localhost;dbname=videogames', 'root', '');
	$reponse = $bdd->query('SELECT Title,ReleaseDate,idPlatform,idPublisher,idDeveloper FROM videogames');
	$content = '';

	while ($donnees = $reponse->fetch()){
	$reponse2 = $bdd->query('SELECT name FROM platform WHERE id = "'.$donnees['idPlatform'].'"');
	while ($donnees2 = $reponse2->fetch()){
	$reponse3 = $bdd->query('SELECT name FROM publishers WHERE id = "'.$donnees['idPublisher'].'"');
	while ($donnees3 = $reponse3->fetch()){
	$reponse4 = $bdd->query('SELECT name FROM developers WHERE id = "'.$donnees['idDeveloper'].'"');	while ($donnees4 = $reponse4->fetch()){
				$content .='<tr>';
				$content .='<td class="text-center bg-dark text-white">'. $donnees['Title']. '</td>';
				$content .='<td class="text-center bg-dark text-white">'. $donnees['ReleaseDate']. '</td>';
				$content .='<td class="text-center bg-dark text-white">'. $donnees2['name']. '</td>'; // PLATFORMS
				$content .='<td class="text-center bg-dark text-white">'. $donnees3['name']. '</td>'; // PUBLISHERS
				$content .='<td class="text-center bg-dark text-white">'. $donnees4['name']. '</td>'; // DEVELOPERS
				$content .='</tr>';
				}
			}
		}
	}
	?>	

<table class="table-striped" id="game">

  <thead class=" thead-light">

   <tr>
    <th class="text-center text-primary p-2 bg-dark text-white">Title</th>
    <th class="text-center text-primary bg-dark text-white">ReleaseDate</th>
    <th class="text-center text-primary bg-dark text-white">Platform</th>
    <th class="text-center text-primary bg-dark text-white">Publisher</th>
    <th class="text-center text-primary bg-dark text-white">Developer</th>
  </tr>

</thead>
<tbody>
 <?php
 echo $content;
 ?>
</tbody>
</table>

	</section>
</body>
</html>