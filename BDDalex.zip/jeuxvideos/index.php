<?php
    ## FORMULAIRE DE CONNEXION
?>

<html lang="fr">
    <head>
    <meta charset="UTF-8">
    </head>
    <body>
    <form action="bdd.php" method="check">
    
    <div>
    	<div style='text-align: center ; background-color:lightblue'>
        <label for="user">Pseudonyme :</label>
        <input type="text" id="nom" name="user_nom">
    	</div>
    </div>
    <br>

    <div>
    	<div style='text-align: center ; background-color:lightblue'>
        <label for="password">Mot de Passe :</label>
        <input type="text" id="password" name="user_motdepasse">
    	</div>
    </div>

    <br>
    <div style='text-align: center ; background-color:lightblue'>
        <input type="submit" id="connexion">
    </div>
</form>

<?php
if(isset($_GET["error"]) == "true"){
    echo "<div style='background-color:red'><label>ERREUR DE CONNEXION</label></div>";
}
?>

    </body>
</html>